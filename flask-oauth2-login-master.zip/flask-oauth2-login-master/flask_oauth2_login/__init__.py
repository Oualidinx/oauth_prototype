from .base import OAuth2Login
from .coursera import CourseraLogin
from .google import GoogleLogin
from .linkedin import LinkedInLogin
